export interface IProduct {
  id?: number;
  product_id?: number;
  product_name?: string;
  Freshness_id?: string;
  category_id?:number;
  Additional_Des?: string;
  Files_id?: number;
  Price?:any;
  Comments?: string;


}
