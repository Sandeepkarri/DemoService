import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { IProduct } from '../_models';
import { ProductService } from '../_services';



@Component({ selector: 'app-list-product', templateUrl: 'list-product.component.html' })
export class ListProductComponent implements OnInit {
  prod?: IProduct[];

  constructor(private productService: ProductService) { }

    ngOnInit() {
        this.productService.getAll()
          .pipe(first())
          .subscribe((prod: IProduct[]) => {
            this.prod = prod;
            console.log(JSON.stringify(this.prod));
          });
    }
}
